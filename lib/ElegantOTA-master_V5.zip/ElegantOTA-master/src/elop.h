#ifndef elop_h
#define elop_h

#include <Arduino.h>

extern const uint8_t ELEGANT_HTML[10214];

#endif
